﻿namespace Class_W10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_kiri2 = new System.Windows.Forms.Button();
            this.numeric_teamnum = new System.Windows.Forms.NumericUpDown();
            this.btn_kiri = new System.Windows.Forms.Button();
            this.btn_kanan = new System.Windows.Forms.Button();
            this.btn_kanan2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_save = new System.Windows.Forms.Button();
            this.lb_id = new System.Windows.Forms.Label();
            this.lb_name = new System.Windows.Forms.Label();
            this.birthdate = new System.Windows.Forms.DateTimePicker();
            this.lb_nationality = new System.Windows.Forms.Label();
            this.cb_team = new System.Windows.Forms.ComboBox();
            this.dgv_player = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.numeric_teamnum)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_player)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_kiri2
            // 
            this.btn_kiri2.Location = new System.Drawing.Point(51, 42);
            this.btn_kiri2.Name = "btn_kiri2";
            this.btn_kiri2.Size = new System.Drawing.Size(213, 186);
            this.btn_kiri2.TabIndex = 0;
            this.btn_kiri2.Text = "<<";
            this.btn_kiri2.UseVisualStyleBackColor = true;
            this.btn_kiri2.Click += new System.EventHandler(this.btn_kiri2_Click);
            // 
            // numeric_teamnum
            // 
            this.numeric_teamnum.Location = new System.Drawing.Point(240, 536);
            this.numeric_teamnum.Name = "numeric_teamnum";
            this.numeric_teamnum.Size = new System.Drawing.Size(120, 31);
            this.numeric_teamnum.TabIndex = 1;
            // 
            // btn_kiri
            // 
            this.btn_kiri.Location = new System.Drawing.Point(307, 42);
            this.btn_kiri.Name = "btn_kiri";
            this.btn_kiri.Size = new System.Drawing.Size(213, 186);
            this.btn_kiri.TabIndex = 2;
            this.btn_kiri.Text = "<";
            this.btn_kiri.UseVisualStyleBackColor = true;
            this.btn_kiri.Click += new System.EventHandler(this.btn_kiri_Click);
            // 
            // btn_kanan
            // 
            this.btn_kanan.Location = new System.Drawing.Point(568, 42);
            this.btn_kanan.Name = "btn_kanan";
            this.btn_kanan.Size = new System.Drawing.Size(213, 186);
            this.btn_kanan.TabIndex = 3;
            this.btn_kanan.Text = ">";
            this.btn_kanan.UseVisualStyleBackColor = true;
            this.btn_kanan.Click += new System.EventHandler(this.btn_kanan_Click);
            // 
            // btn_kanan2
            // 
            this.btn_kanan2.Location = new System.Drawing.Point(823, 42);
            this.btn_kanan2.Name = "btn_kanan2";
            this.btn_kanan2.Size = new System.Drawing.Size(213, 186);
            this.btn_kanan2.TabIndex = 4;
            this.btn_kanan2.Text = ">>";
            this.btn_kanan2.UseVisualStyleBackColor = true;
            this.btn_kanan2.Click += new System.EventHandler(this.btn_kanan2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(70, 283);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Player ID: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(70, 334);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(147, 25);
            this.label2.TabIndex = 6;
            this.label2.Text = "Player Name: ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(70, 386);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 25);
            this.label3.TabIndex = 7;
            this.label3.Text = "Birthdate: ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(70, 442);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 25);
            this.label4.TabIndex = 8;
            this.label4.Text = "Nationality: ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(70, 488);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(78, 25);
            this.label5.TabIndex = 9;
            this.label5.Text = "Team: ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(70, 538);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(159, 25);
            this.label6.TabIndex = 10;
            this.label6.Text = "Team Number: ";
            // 
            // btn_save
            // 
            this.btn_save.Location = new System.Drawing.Point(240, 596);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(117, 37);
            this.btn_save.TabIndex = 11;
            this.btn_save.Text = "Save";
            this.btn_save.UseVisualStyleBackColor = true;
            // 
            // lb_id
            // 
            this.lb_id.AutoSize = true;
            this.lb_id.Location = new System.Drawing.Point(235, 282);
            this.lb_id.Name = "lb_id";
            this.lb_id.Size = new System.Drawing.Size(70, 25);
            this.lb_id.TabIndex = 12;
            this.lb_id.Text = "label7";
            // 
            // lb_name
            // 
            this.lb_name.AutoSize = true;
            this.lb_name.Location = new System.Drawing.Point(235, 334);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(70, 25);
            this.lb_name.TabIndex = 13;
            this.lb_name.Text = "label7";
            // 
            // birthdate
            // 
            this.birthdate.Location = new System.Drawing.Point(240, 386);
            this.birthdate.Name = "birthdate";
            this.birthdate.Size = new System.Drawing.Size(421, 31);
            this.birthdate.TabIndex = 14;
            // 
            // lb_nationality
            // 
            this.lb_nationality.AutoSize = true;
            this.lb_nationality.Location = new System.Drawing.Point(235, 442);
            this.lb_nationality.Name = "lb_nationality";
            this.lb_nationality.Size = new System.Drawing.Size(70, 25);
            this.lb_nationality.TabIndex = 15;
            this.lb_nationality.Text = "label7";
            // 
            // cb_team
            // 
            this.cb_team.FormattingEnabled = true;
            this.cb_team.Location = new System.Drawing.Point(240, 488);
            this.cb_team.Name = "cb_team";
            this.cb_team.Size = new System.Drawing.Size(171, 33);
            this.cb_team.TabIndex = 16;
            // 
            // dgv_player
            // 
            this.dgv_player.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_player.Location = new System.Drawing.Point(66, 686);
            this.dgv_player.Name = "dgv_player";
            this.dgv_player.RowHeadersWidth = 82;
            this.dgv_player.RowTemplate.Height = 33;
            this.dgv_player.Size = new System.Drawing.Size(1083, 354);
            this.dgv_player.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 1078);
            this.Controls.Add(this.dgv_player);
            this.Controls.Add(this.cb_team);
            this.Controls.Add(this.lb_nationality);
            this.Controls.Add(this.birthdate);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.lb_id);
            this.Controls.Add(this.btn_save);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_kanan2);
            this.Controls.Add(this.btn_kanan);
            this.Controls.Add(this.btn_kiri);
            this.Controls.Add(this.numeric_teamnum);
            this.Controls.Add(this.btn_kiri2);
            this.Name = "Form1";
            this.Text = "Form 1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numeric_teamnum)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_player)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_kiri2;
        private System.Windows.Forms.NumericUpDown numeric_teamnum;
        private System.Windows.Forms.Button btn_kiri;
        private System.Windows.Forms.Button btn_kanan;
        private System.Windows.Forms.Button btn_kanan2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_save;
        private System.Windows.Forms.Label lb_id;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.DateTimePicker birthdate;
        private System.Windows.Forms.Label lb_nationality;
        private System.Windows.Forms.ComboBox cb_team;
        private System.Windows.Forms.DataGridView dgv_player;
    }
}

