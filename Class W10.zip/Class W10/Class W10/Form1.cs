﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Class_W10
{
    public partial class Form1 : Form
    {
        MySqlConnection sqlConnect;
        MySqlCommand sqlCommand;
        MySqlDataAdapter sqlDataAdapter;

        DataTable dtplayer = new DataTable();
        DataTable dtnation = new DataTable();
        DataTable dtteam = new DataTable();
        public Form1()
        {
            InitializeComponent();

            sqlConnect = new MySqlConnection(
                "server = 192.168.88.201;" +
                $"uid = student;" +
                $"pwd = isbmantap;" +
                $"database = premier_league");

            //sqlConnect.Open();
            //MessageBox.Show("YEY");
            //sqlConnect.Close();

        }

        int index = 0;
        void start()
        {
            string sqlQuery = "select *  from player";

            sqlCommand = new MySqlCommand(sqlQuery, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtplayer);

            dgv_player.DataSource = dtplayer;

            lb_id.Text = dtplayer.Rows[index][0].ToString();
            lb_name.Text = dtplayer.Rows[index]["player_name"].ToString();

            string birth = dtplayer.Rows[index]["birthdate"].ToString();
            birthdate.Text = birth;

            string nation = "select n.nation from player p, nation n where p.nationality_id = n.nationality_id";
            sqlCommand = new MySqlCommand(nation, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtnation);
            lb_nationality.Text = dtplayer.Rows[index]["n.nation"].ToString();

            string team = "select t.team from team t, player p where t.team_id = p.team_id ";
            sqlCommand = new MySqlCommand(team, sqlConnect);
            sqlDataAdapter = new MySqlDataAdapter(sqlCommand);
            sqlDataAdapter.Fill(dtteam);

            foreach (DataRow row in dtteam.Rows)
            {
                cb_team.Items.Add(row);
            }

            numeric_teamnum.Value = dtplayer.Rows[index]["team_number"].ToString();
        }
        
        private void btn_kiri2_Click(object sender, EventArgs e)
        {
            start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            start();
        }

        private void btn_kiri_Click(object sender, EventArgs e)
        {
            index--;
            start(); ;
        }

        private void btn_kanan_Click(object sender, EventArgs e)
        {
            index++;
            start();
        }

        private void btn_kanan2_Click(object sender, EventArgs e)
        {
            int count = dtplayer.Rows.Count;
            index = count;
            start();
        }
    }
}
